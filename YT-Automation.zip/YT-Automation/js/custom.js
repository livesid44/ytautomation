$(document).ready(function () {
  // Add dropdown arrow
  $(".sideNav .dropdown>a span").append('<i class="bi bi-chevron-down"></i>');

  // Dropdown functionality (keep this for submenu toggling)
  $(".sideNav .dropdown>a").click(function (e) {
    e.preventDefault();
    $(this).toggleClass("active");
    $(".sideNav .dropdown>a").not(this).removeClass("active");

    $(".sideNav .dropdown>a")
      .not(this)
      .siblings(".sideNav .subMenu")
      .hide("slow");
    $(this).siblings(".sideNav .subMenu").toggle("slow");
  });

  // Add row to sampling table on button click
  $("#newRow").click(function () {
    var newRow = `<tr>
            <td><div class="form-group"><input type="text" placeholder="150" class="form-control form-control-sm" /></div></td>
            <td><div class="form-group"><input type="text" placeholder="360" class="form-control form-control-sm" /></div></td>
            <td><div class="form-group"><input type="text" placeholder="10" class="form-control form-control-sm" /></div></td>
            <td><img src="images/delete.png" /></td>
        </tr>`;
    $(this).closest(".grey-bg").find("table tbody").append(newRow);
  });
});
